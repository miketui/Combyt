from __future__ import annotations

from pathlib import Path
from typing import Any

from taylkomb_mcp.io_utils import read_json, write_json
from taylkomb_mcp.spec_models import TaylkombSpec


def validate_measurements(spec: TaylkombSpec, measurements: dict[str, Any], part_name: str) -> dict[str, Any]:
    failures: list[str] = []
    checks: dict[str, bool] = {}

    clearance = measurements.get("clearance_per_side_mm")
    if clearance is not None:
        in_range = spec.connector.clearance_per_side_mm_range[0] <= clearance <= spec.connector.clearance_per_side_mm_range[1]
        checks["clearance_per_side"] = in_range
        if not in_range:
            failures.append(
                f"clearance_per_side_mm={clearance} outside {spec.connector.clearance_per_side_mm_range}"
            )

    seam_step = measurements.get("seam_step_mm")
    if seam_step is not None:
        in_range = seam_step <= spec.rules.reject_if_seam_step_gt_mm
        checks["seam_step"] = in_range
        if not in_range:
            failures.append(
                f"seam_step_mm={seam_step} exceeds {spec.rules.reject_if_seam_step_gt_mm}"
            )

    if part_name == "round_handle":
        tip = measurements.get("tip_diameter_mm")
        tip_range = spec.part_targets["round_handle"].tip_diameter_mm_range
        if tip is not None and tip_range is not None:
            in_range = tip_range[0] <= tip <= tip_range[1]
            checks["tip_diameter"] = in_range
            if not in_range:
                failures.append(f"tip_diameter_mm={tip} outside {tip_range}")

    if part_name == "double_handle":
        outer_width = measurements.get("outer_width_mm")
        target = spec.part_targets["double_handle"].outer_width_mm_target
        if outer_width is not None and target is not None:
            in_range = outer_width >= 30.0
            checks["outer_width_minimum"] = in_range
            if not in_range:
                failures.append(f"outer_width_mm={outer_width} below minimum ergonomic threshold")

    return {
        "passed": not failures,
        "checks": checks,
        "failures": failures,
    }


def rank_variants(variants: list[dict[str, Any]]) -> list[dict[str, Any]]:
    def score(v: dict[str, Any]) -> tuple[int, int, float]:
        passed = 1 if v.get("validation", {}).get("passed") else 0
        failure_count = len(v.get("validation", {}).get("failures", []))
        penalty = float(v.get("metrics", {}).get("seam_step_mm", 0.0))
        return (passed, -failure_count, -penalty)

    return sorted(variants, key=score, reverse=True)

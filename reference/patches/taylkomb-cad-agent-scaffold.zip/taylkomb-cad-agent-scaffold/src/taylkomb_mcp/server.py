from __future__ import annotations

from pathlib import Path
from typing import Any

import typer
from mcp.server.fastmcp import FastMCP

from taylkomb_mcp.io_utils import project_root
from taylkomb_mcp.server_logic import (
    compare_variants_logic,
    export_release_pack_logic,
    generate_connector_variant_logic,
    measure_geometry_logic,
    validate_connector_rules_logic,
)

mcp = FastMCP("TAYLKOMB CAD Agent", json_response=True)
app = typer.Typer(add_completion=False)


@mcp.resource("spec://taylkomb/rev-c")
def rev_c_spec_resource() -> str:
    spec_path = project_root() / "specs" / "taylkomb_revC_master.json"
    return spec_path.read_text(encoding="utf-8")


@mcp.resource("policy://taylkomb/locked-datums")
def locked_datums_resource() -> str:
    policy_path = project_root() / "agent" / "policies" / "locked_datums.json"
    return policy_path.read_text(encoding="utf-8")


@mcp.tool()
def generate_connector_variant(
    spec_path: str,
    variant_id: str,
    part_name: str,
    backend: str = "cadquery",
    overrides: dict[str, Any] | None = None,
    output_formats: list[str] | None = None,
) -> dict[str, Any]:
    """Generate a TAYLKOMB CAD variant from a locked JSON spec."""
    return generate_connector_variant_logic(
        spec_path=spec_path,
        variant_id=variant_id,
        part_name=part_name,
        backend=backend,
        overrides=overrides or {},
        output_formats=output_formats or ["step", "stl"],
    )


@mcp.tool()
def measure_geometry(model_path: str, checks: list[str]) -> dict[str, Any]:
    """Measure geometry from scaffold-generated artifacts or sidecar metric files."""
    return measure_geometry_logic(model_path=model_path, checks=checks)


@mcp.tool()
def validate_connector_rules(spec_path: str, measurement_path: str, part_name: str) -> dict[str, Any]:
    """Validate a measurement payload against the TAYLKOMB rule pack."""
    return validate_connector_rules_logic(
        spec_path=spec_path,
        measurement_path=measurement_path,
        part_name=part_name,
    )


@mcp.tool()
def compare_variants(variant_records: list[dict[str, Any]]) -> dict[str, Any]:
    """Rank variant records by pass/fail status and severity of issues."""
    return compare_variants_logic(variant_records)


@mcp.tool()
def export_release_pack(variant_id: str, include: list[str]) -> dict[str, Any]:
    """Zip release artifacts for a chosen variant."""
    return export_release_pack_logic(variant_id=variant_id, include=include)


@app.command()
def run(
    transport: str = typer.Option("stdio", help="stdio or streamable-http"),
) -> None:
    if transport == "stdio":
        mcp.run(transport="stdio")
    elif transport == "streamable-http":
        mcp.run(transport="streamable-http")
    else:
        raise typer.BadParameter("transport must be 'stdio' or 'streamable-http'")


def main() -> None:
    app()


if __name__ == "__main__":
    main()

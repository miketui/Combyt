from __future__ import annotations

from typing import Any

import cadquery as cq

from taylkomb_mcp.cad.connector_common import add_detent_pocket, build_female_socket, build_male_rail, drill_ball_bore
from taylkomb_mcp.spec_models import TaylkombSpec


DENSITY_G_PER_MM3 = {
    "PPS-CF40": 0.00155,
    "316L_stainless_hollow": 0.00800,
    "316L_stainless": 0.00800,
}


def build_comb_connector_block(spec: TaylkombSpec, part_name: str, overrides: dict[str, Any] | None = None) -> cq.Workplane:
    overrides = overrides or {}
    rail_width = spec.connector.rail_profile_mm.width + overrides.get("rail_width_delta_mm", 0.0)
    rail_height = spec.connector.rail_profile_mm.height + overrides.get("rail_height_delta_mm", 0.0)
    engagement = overrides.get("engagement_length_mm", spec.connector.engagement_length_mm_target)
    block = cq.Workplane("XY").box(16.0, 8.0, engagement + 4.0, centered=(True, True, False))
    female_socket = build_female_socket(spec, engagement_length_mm=engagement, clearance_per_side_mm=overrides.get("clearance_per_side_mm"))
    block = block.cut(female_socket)
    block = add_detent_pocket(block, spec)
    return block


def build_handle_connector_block(spec: TaylkombSpec, part_name: str, overrides: dict[str, Any] | None = None) -> cq.Workplane:
    overrides = overrides or {}
    engagement = overrides.get("engagement_length_mm", spec.connector.engagement_length_mm_target)
    block = cq.Workplane("XY").box(16.0, 8.0, engagement + 6.0, centered=(True, True, False))
    male = build_male_rail(spec, engagement_length_mm=engagement)
    block = block.union(male.translate((0.0, 0.0, 2.0)))
    block = drill_ball_bore(block, spec)
    return block


def build_round_handle(spec: TaylkombSpec, overrides: dict[str, Any] | None = None) -> cq.Workplane:
    overrides = overrides or {}
    target = spec.part_targets["round_handle"]
    oal = overrides.get("oal_mm", target.oal_mm_target)
    tip = overrides.get("tip_diameter_mm", target.tip_diameter_mm_target or 2.2)
    shaft = (
        cq.Workplane("XZ")
        .moveTo(0.0, 0.0)
        .lineTo(0.0, 8.0)
        .lineTo(oal * 0.2, 6.0)
        .lineTo(oal, tip)
        .lineTo(oal, 0.0)
        .close()
        .revolve(360.0, (0, 0), (1, 0))
    )
    connector = build_handle_connector_block(spec, "round_handle", overrides)
    return connector.union(shaft.translate((0.0, 0.0, 8.0)))


def build_flat_handle(spec: TaylkombSpec, overrides: dict[str, Any] | None = None) -> cq.Workplane:
    overrides = overrides or {}
    target = spec.part_targets["flat_handle"]
    oal = overrides.get("oal_mm", target.oal_mm_target)
    width = overrides.get("grip_width_mm", 22.0)
    thickness = overrides.get("grip_thickness_mm", 10.0)
    body = cq.Workplane("XY").box(oal, width, thickness, centered=(False, True, False)).edges("|Z").fillet(1.5)
    connector = build_handle_connector_block(spec, "flat_handle", overrides)
    return connector.union(body.translate((8.0, 0.0, 0.0)))


def build_double_handle(spec: TaylkombSpec, overrides: dict[str, Any] | None = None) -> cq.Workplane:
    overrides = overrides or {}
    target = spec.part_targets["double_handle"]
    oal = overrides.get("oal_mm", target.oal_mm_target)
    outer_width = overrides.get("outer_width_mm", target.outer_width_mm_target or 35.0)
    prong = target.prong_section_mm_target or {"x": 8.0, "y": 9.0}
    prong_x = overrides.get("prong_x_mm", prong["x"])
    prong_y = overrides.get("prong_y_mm", prong["y"])
    fork_len = overrides.get("fork_length_mm", target.fork_length_mm_target or 130.0)

    left = cq.Workplane("XY").box(fork_len, prong_x, prong_y, centered=(False, True, False)).translate((8.0, -outer_width / 4.0, 0.0))
    right = cq.Workplane("XY").box(fork_len, prong_x, prong_y, centered=(False, True, False)).translate((8.0, outer_width / 4.0, 0.0))
    bridge = cq.Workplane("XY").box(24.0, outer_width, prong_y, centered=(False, True, False))
    connector = build_handle_connector_block(spec, "double_handle", overrides)
    return connector.union(left).union(right).union(bridge)


def build_main_comb(spec: TaylkombSpec, overrides: dict[str, Any] | None = None) -> cq.Workplane:
    overrides = overrides or {}
    target = spec.part_targets["main_comb"]
    oal = overrides.get("oal_mm", target.oal_mm_target)
    body = cq.Workplane("XY").box(oal, 50.8, 3.0, centered=(False, True, False)).edges("|Z").fillet(0.8)
    connector = build_comb_connector_block(spec, "main_comb", overrides)
    return connector.union(body.translate((16.0, 0.0, 0.0)))


def build_narrow_comb(spec: TaylkombSpec, overrides: dict[str, Any] | None = None) -> cq.Workplane:
    overrides = overrides or {}
    target = spec.part_targets["narrow_comb"]
    oal = overrides.get("oal_mm", target.oal_mm_target)
    body = cq.Workplane("XY").box(oal, 36.0, 2.8, centered=(False, True, False)).edges("|Z").fillet(0.8)
    connector = build_comb_connector_block(spec, "narrow_comb", overrides)
    return connector.union(body.translate((16.0, 0.0, 0.0)))


def build_wide_comb(spec: TaylkombSpec, overrides: dict[str, Any] | None = None) -> cq.Workplane:
    overrides = overrides or {}
    target = spec.part_targets["wide_comb"]
    oal = overrides.get("oal_mm", target.oal_mm_target)
    body = cq.Workplane("XY").box(oal, 58.0, 3.2, centered=(False, True, False)).edges("|Z").fillet(0.8)
    connector = build_comb_connector_block(spec, "wide_comb", overrides)
    return connector.union(body.translate((16.0, 0.0, 0.0)))


PART_BUILDERS = {
    "main_comb": build_main_comb,
    "wide_comb": build_wide_comb,
    "narrow_comb": build_narrow_comb,
    "round_handle": build_round_handle,
    "flat_handle": build_flat_handle,
    "double_handle": build_double_handle,
}


def build_part(part_name: str, spec: TaylkombSpec, overrides: dict[str, Any] | None = None) -> cq.Workplane:
    if part_name not in PART_BUILDERS:
        raise KeyError(f"Unknown part name: {part_name}")
    return PART_BUILDERS[part_name](spec, overrides or {})

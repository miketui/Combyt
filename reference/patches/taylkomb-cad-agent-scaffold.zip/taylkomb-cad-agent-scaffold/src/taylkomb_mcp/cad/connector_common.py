from __future__ import annotations

from pathlib import Path
from typing import Any

import cadquery as cq

from taylkomb_mcp.spec_models import TaylkombSpec


class GeometryBuildError(RuntimeError):
    """Raised when CAD generation fails."""


def _make_dovetail_profile(width: float, height: float, included_angle_deg: float) -> cq.Sketch:
    half_width = width / 2.0
    half_height = height / 2.0
    taper_dx = height / (2.0 * max(0.001, (included_angle_deg / 60.0)))
    pts = [
        (-half_width + taper_dx, -half_height),
        (half_width - taper_dx, -half_height),
        (half_width, half_height),
        (-half_width, half_height),
    ]
    return cq.Sketch().polygon(pts)


def build_male_rail(spec: TaylkombSpec, engagement_length_mm: float | None = None) -> cq.Workplane:
    rail = spec.connector.rail_profile_mm
    engagement = engagement_length_mm or spec.connector.engagement_length_mm_target
    profile = _make_dovetail_profile(rail.width, rail.height, spec.connector.dovetail_angle_deg)
    return cq.Workplane("XY").placeSketch(profile).extrude(engagement)


def build_female_socket(spec: TaylkombSpec, engagement_length_mm: float | None = None, clearance_per_side_mm: float | None = None) -> cq.Workplane:
    rail = spec.connector.rail_profile_mm
    engagement = engagement_length_mm or spec.connector.engagement_length_mm_target
    clearance = clearance_per_side_mm or spec.connector.clearance_per_side_mm_range[0]

    outer = cq.Workplane("XY").box(
        rail.width + 8.0,
        rail.height + 8.0,
        engagement + 4.0,
        centered=(True, True, False),
    )
    socket_profile = _make_dovetail_profile(
        rail.width + (clearance * 2.0),
        rail.height + (clearance * 2.0),
        spec.connector.dovetail_angle_deg,
    )
    inner = cq.Workplane("XY").placeSketch(socket_profile).extrude(engagement + 2.0)
    return outer.cut(inner)


def drill_ball_bore(body: cq.Workplane, spec: TaylkombSpec, x_offset: float = 0.0, z_height: float | None = None) -> cq.Workplane:
    rail = spec.connector.rail_profile_mm
    z_pos = z_height if z_height is not None else spec.connector.engagement_length_mm_target - 3.0
    return (
        body.faces(">Y")
        .workplane(centerOption="CenterOfMass")
        .transformed(offset=(x_offset, 0.0, z_pos))
        .hole(spec.connector.ball_diameter_mm + 0.6)
    )


def add_detent_pocket(body: cq.Workplane, spec: TaylkombSpec, z_pos: float | None = None) -> cq.Workplane:
    z = z_pos if z_pos is not None else spec.connector.engagement_length_mm_target - 1.5
    pocket_radius = spec.connector.detent_pocket_diameter_mm / 2.0
    return (
        body.faces(">Z")
        .workplane(centerOption="CenterOfMass")
        .center(0.0, 0.0)
        .pushPoints([(0.0, 0.0)])
        .cskHole(
            diameter=spec.connector.detent_pocket_diameter_mm,
            depth=spec.connector.detent_pocket_depth_mm,
            cskDiameter=spec.connector.detent_pocket_diameter_mm,
            cskAngle=90.0,
        )
    )


def export_shape(shape: cq.Workplane, output_path: str | Path) -> str:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix.lower()
    if suffix == ".step":
        cq.exporters.export(shape, str(path))
    elif suffix == ".stl":
        cq.exporters.export(shape, str(path), tolerance=0.01, angularTolerance=0.1)
    elif suffix == ".svg":
        cq.exporters.export(shape, str(path))
    else:
        raise GeometryBuildError(f"Unsupported export format: {suffix}")
    return str(path)


def bounding_box(shape: cq.Workplane) -> dict[str, float]:
    bb = shape.val().BoundingBox()
    return {
        "xlen": bb.xlen,
        "ylen": bb.ylen,
        "zlen": bb.zlen,
        "xmin": bb.xmin,
        "xmax": bb.xmax,
        "ymin": bb.ymin,
        "ymax": bb.ymax,
        "zmin": bb.zmin,
        "zmax": bb.zmax,
    }


def volume_mm3(shape: cq.Workplane) -> float:
    return float(shape.val().Volume())

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, ValidationError


class RailProfile(BaseModel):
    width: float
    height: float


class RangeSpec(BaseModel):
    min: float
    max: float


class MaterialSpec(BaseModel):
    primary: str
    wall_thickness_mm_range: list[float] | None = None


class Materials(BaseModel):
    comb_heads: MaterialSpec
    handles: MaterialSpec


class ConnectorSpec(BaseModel):
    dovetail_angle_deg: float
    rail_profile_mm: RailProfile
    engagement_length_mm_target: float
    engagement_length_mm_range: list[float]
    clearance_per_side_mm_range: list[float]
    ball_diameter_mm: float
    ball_protrusion_mm: float
    detent_pocket_diameter_mm: float
    detent_pocket_depth_mm: float
    detent_force_N_range: list[float]
    lead_in_chamfer: dict[str, float]
    hair_shed_chamfer: dict[str, float]
    seam_step_max_mm: float
    cycle_life_target_min: int


class PartTarget(BaseModel):
    oal_mm_target: float
    tail_length_mm_target: float | None = None
    work_section_mm_target: float | None = None
    fork_length_mm_target: float | None = None
    outer_width_mm_target: float | None = None
    tip_diameter_mm_target: float | None = None
    tip_diameter_mm_range: list[float] | None = None
    prong_section_mm_target: dict[str, float] | None = None
    root_fillet_mm_target: float | None = None


class AssemblyTargets(BaseModel):
    assembled_length_mm_range: list[float]
    assembled_weight_g_target_range: list[float]
    assembled_weight_g_max: float


class RulePack(BaseModel):
    allow_changes_to_locked_datums: bool = False
    require_step_export: bool = True
    require_measurement_report: bool = True
    reject_if_seam_step_gt_mm: float
    reject_if_clearance_outside_range: bool = True
    reject_if_tip_diameter_outside_range: bool = True


class TaylkombSpec(BaseModel):
    project: str
    revision: str
    units: Literal["mm"]
    architecture: str
    locked_datums: dict[str, Any]
    materials: Materials
    connector: ConnectorSpec
    part_targets: dict[str, PartTarget]
    assembly_targets: AssemblyTargets
    rules: RulePack


def load_spec(path: str | Path) -> TaylkombSpec:
    import json

    with Path(path).open("r", encoding="utf-8") as f:
        raw = json.load(f)
    return TaylkombSpec.model_validate(raw)


def save_spec(spec: TaylkombSpec, path: str | Path) -> None:
    import json

    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with Path(path).open("w", encoding="utf-8") as f:
        json.dump(spec.model_dump(mode="json"), f, indent=2)


def coerce_spec_override(base: TaylkombSpec, overrides: dict[str, Any]) -> TaylkombSpec:
    merged = base.model_dump(mode="json")
    _deep_merge(merged, overrides)
    return TaylkombSpec.model_validate(merged)


def _deep_merge(target: dict[str, Any], patch: dict[str, Any]) -> None:
    for key, value in patch.items():
        if isinstance(value, dict) and isinstance(target.get(key), dict):
            _deep_merge(target[key], value)
        else:
            target[key] = value

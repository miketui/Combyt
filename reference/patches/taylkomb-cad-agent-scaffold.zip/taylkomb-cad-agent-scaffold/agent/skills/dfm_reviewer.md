# Skill — DFM Reviewer

Purpose:
Flag likely manufacturing or usability risks before prototype release.

Checks to discuss in every report:
- tolerance sensitivity
- likely snag points
- likely wear points
- likely fatigue points
- weight / balance drift
- cleanup needed before CNC / mold handoff

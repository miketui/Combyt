# Skill — Connector Synthesizer

Purpose:
Generate connector variants only inside the approved architecture.

Allowed sweeps:
- clearance_per_side_mm
- engagement_length_mm
- detent_pocket_depth_mm
- detent_force_N_range (report-level recommendation only)
- round handle tip diameter
- part OAL targets that are already unlocked in the spec

Disallowed:
- switching to magnetic-only
- switching to pure snap-fit
- switching to bayonet/twist-lock unless the user explicitly forks the architecture

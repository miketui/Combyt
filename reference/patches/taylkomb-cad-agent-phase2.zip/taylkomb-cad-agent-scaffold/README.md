# TAYLKOMB Claude Code + MCP CAD Scaffold

A production-oriented scaffold for a Claude Code / MCP workflow that generates, validates, compares, and packages TAYLKOMB CAD connector variants.

This scaffold is built around:

- **Claude Code** as the local agent harness
- **MCP** as the tool interface
- **CadQuery** as the primary code-to-CAD backend
- **Pydantic** for locked spec validation
- **JSON specs** for deterministic geometry generation

## What this scaffold includes

- Local Claude Code MCP config (`.mcp.json`)
- Python MCP server with real tool contracts
- Parametric spec models
- TAYLKOMB Rev C master spec
- Connector variant generation flow
- Measurement + rule validation flow
- Artifact export pack flow
- Optional SDK runner example
- Basic tests and project structure

## Important scope note

This is a **scaffold**, not a finished geometry package for manufacturing. It encodes the architecture, tool contracts, locked datums, variant sweep logic, and validation workflow so your build environment can be stood up quickly.

You still need to:

1. install dependencies,
2. refine the CadQuery geometry in `src/taylkomb_mcp/cad/connector_common.py` and `parts.py`,
3. connect any external simulation / metrology tools you want through MCP,
4. prototype and physically validate.

## Recommended local stack

- Python 3.11+
- Node.js 18+
- `claude-code-sdk`
- `@anthropic-ai/claude-code`
- `mcp[cli]`
- `cadquery`

## Quick start

### 1) Create and activate a virtual environment

```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -e .
```

### 2) Install Claude Code CLI

```bash
npm install -g @anthropic-ai/claude-code
```

### 3) Verify the MCP server locally

```bash
python -m taylkomb_mcp.server --transport stdio
```

### 4) Use from Claude Code

From the project root:

```bash
claude
```

Claude Code will pick up `.mcp.json` and expose the server tools.

### 5) Generate a first connector variant

Prompt Claude Code with something like:

```text
Use the TAYLKOMB MCP tools to generate three connector variants from specs/taylkomb_revC_master.json. Keep locked datums fixed. Sweep only rail clearance, engagement length, and detent pocket depth. Export STEP, STL, preview PNG, measurement JSON, and markdown report. Reject any variant that violates seam step, tip range, or assembled length rules.
```

## Optional: run as HTTP MCP server

```bash
python -m taylkomb_mcp.server --transport streamable-http --host 127.0.0.1 --port 8000
```

Then point a remote-compatible MCP client at `http://127.0.0.1:8000/mcp`.

## Project layout

```text
.
├── .mcp.json
├── .env.example
├── README.md
├── pyproject.toml
├── agent/
├── specs/
├── scripts/
├── src/
├── tests/
└── data/
```

## Main MCP tools

- `generate_connector_variant`
- `measure_geometry`
- `validate_connector_rules`
- `compare_variants`
- `export_release_pack`

## Design policy encoded here

- Locked connector datums remain fixed unless explicitly unlocked.
- Only approved dimensions are swept.
- Geometry must be exportable to STEP to pass.
- Reports are emitted for every variant.
- The agent should optimize the selected connector architecture, not reinvent the connector concept each run.

## Suggested next edits in your environment

1. replace the placeholder comb body profiles with your exact real tooth geometry,
2. add mass-property calibration using actual material densities,
3. wire in simulation or interference-check tools if you have them,
4. add rendering via CQ-editor, OCP, or external preview pipeline,
5. add a release-grade CI check for spec drift.


## Phase 2 additions

- dedicated geometry modules for combs and handles
- simple assembly generation using `main_comb+handle` part names
- richer validation against Rev C length and mass bands
- precision and power-family sweep JSON files
- a batch demo script at `scripts/generate_phase2_demo.py`

See `PHASE2_NOTES.md` for scope and limits.

from __future__ import annotations

from typing import Any

import cadquery as cq

from taylkomb_mcp.cad.combs import build_main_comb, build_narrow_comb, build_wide_comb
from taylkomb_mcp.cad.handles import build_double_handle, build_flat_handle, build_round_handle
from taylkomb_mcp.spec_models import TaylkombSpec


DENSITY_G_PER_MM3 = {
    "PPS-CF40": 0.00155,
    "316L_stainless_hollow": 0.00800,
    "316L_stainless": 0.00800,
}


PART_BUILDERS = {
    "main_comb": build_main_comb,
    "wide_comb": build_wide_comb,
    "narrow_comb": build_narrow_comb,
    "round_handle": build_round_handle,
    "flat_handle": build_flat_handle,
    "double_handle": build_double_handle,
}


def build_part(part_name: str, spec: TaylkombSpec, overrides: dict[str, Any] | None = None) -> cq.Workplane:
    if part_name not in PART_BUILDERS:
        raise KeyError(f"Unknown part name: {part_name}")
    return PART_BUILDERS[part_name](spec, overrides or {})

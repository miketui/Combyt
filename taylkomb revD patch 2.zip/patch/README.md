# TAYLKOMB Rev D Patch — Drop-In Instructions

This folder is a drop-in patch for the existing `taylkomb-cad-agent-scaffold/` repo.
Copy each file to the matching path in the scaffold (overwriting where a file already exists).

## File map

```
patch/                                         →  repo root
├── specs/
│   ├── taylkomb_revD_master.json              →  specs/taylkomb_revD_master.json   (NEW)
│   └── variant_sweeps/
│       ├── sweep_A.json                       →  specs/variant_sweeps/sweep_A.json (OVERWRITE)
│       ├── sweep_B.json                       →  specs/variant_sweeps/sweep_B.json (NEW)
│       └── sweep_C.json                       →  specs/variant_sweeps/sweep_C.json (NEW)
├── agent/
│   ├── policies/
│   │   ├── locked_datums.json                 →  agent/policies/locked_datums.json    (OVERWRITE)
│   │   └── pass_fail_rules.json               →  agent/policies/pass_fail_rules.json  (OVERWRITE)
│   └── skills/
│       ├── dfm_reviewer.md                    →  agent/skills/dfm_reviewer.md         (OVERWRITE)
│       └── connector_synthesizer.md           →  agent/skills/connector_synthesizer.md (OVERWRITE)
└── src/
    └── taylkomb_mcp/
        ├── spec_guard.py                      →  src/taylkomb_mcp/spec_guard.py       (NEW)
        └── cad/
            ├── locking_module.py              →  src/taylkomb_mcp/cad/locking_module.py (NEW, replaces connector_common.py role)
            ├── comb_blank.py                  →  src/taylkomb_mcp/cad/comb_blank.py   (NEW)
            └── parts.py                       →  src/taylkomb_mcp/cad/parts.py        (OVERWRITE)
```

## Steps

1. Unzip the patch into a staging folder.
2. From the repo root, copy recursively:
   ```bash
   cp -r patch/specs/*                  specs/
   cp -r patch/agent/policies/*         agent/policies/
   cp -r patch/agent/skills/*           agent/skills/
   cp    patch/src/taylkomb_mcp/spec_guard.py  src/taylkomb_mcp/
   cp    patch/src/taylkomb_mcp/cad/*   src/taylkomb_mcp/cad/
   ```
3. Wire the Spec Guard into `server_logic.py` — add one line after the spec is loaded:
   ```python
   from taylkomb_mcp.spec_guard import assert_overrides_safe
   ...
   def generate_connector_variant_logic(...):
       spec = load_spec(spec_path)
       overrides = overrides or {}
       assert_overrides_safe(overrides)       # ← ADD THIS LINE
       ...
   ```
4. Update `.mcp.json` default spec path:
   ```json
   "TAYLKOMB_DEFAULT_SPEC": "${PWD}/specs/taylkomb_revD_master.json"
   ```
5. Update `spec_models.py` to accept the Rev D fields. If the existing Pydantic models
   only know Rev C fields, add the new nested groups (`socket_mm`, `stem_mm`,
   `ball_plunger`, `release_button_mm`, `connector_forces_N`) — or temporarily loosen
   the model with `model_config = ConfigDict(extra='allow')` while you iterate.
6. Run `pytest -q` to confirm nothing is broken.
7. Start Claude Code from the repo root. It will auto-load `CLAUDE.md` and the patched
   files together.

## Smoke test

Once patched, run this first prompt in Claude Code:

> Run sweep_A end-to-end and produce a summary. Follow the locked SOP in CLAUDE.md.

Expected behavior: 6 parts generate, 6 validations run, 5–6 pass, 1–2 WARN on
assembled length (expected — see Deliverable 1 §5), release packs written to
`data/reports/`.
